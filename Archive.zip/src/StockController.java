
interface StockController {

  public void startProgram();
}